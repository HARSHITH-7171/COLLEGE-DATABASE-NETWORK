
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Adddata_usage extends JFrame {
	private static final long serialVersionUID = 1L;
	static Adddata_usage frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Adddata_usage();
					frame.setTitle("Data Usage Info.");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adddata_usage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(928, 380, 450, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblAdddata_usage = new JLabel("Add Data Usage Details");
		lblAdddata_usage.setForeground(Color.MAGENTA);
		lblAdddata_usage.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JLabel lbldid = new JLabel("Department ID :");
		
		JLabel lblday = new JLabel("Day Number:");
		
		JLabel lbldevices_connected = new JLabel("No. of devices connected :");
		
		JLabel lbldata_bandwidth_GB = new JLabel("Amount of Data Consumed(GB) :");
		
		JLabel lbldate = new JLabel("Date :");
		
		
		
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		
		
		JButton btnAdddata_usage = new JButton("Submit");
		btnAdddata_usage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			//String dname=textField_1.getText();
			//String ip_address=textField_2.getText();
			//int did = textField.getText();
			int did = Integer.parseInt(textField.getText());
			int day = Integer.parseInt(textField_1.getText());
			int devices_connected = Integer.parseInt(textField_2.getText());
			float data_bandwidth_GB = Float.parseFloat(textField_3.getText());
			 
			//String date = df.format(dateChooserFrom.getText()); 
			String date=textField_4.getText();
				
			
			
			if(date.equals("") /*|| ip_address.equals("")*/ )
			{
				JOptionPane.showMessageDialog(Adddata_usage.this,"Fields Cannot be Blank!");
			}
			else {
			int id=Integer.parseInt(textField.getText());
			/*if(Data_usagedetails.checkdid(id)) {
				JOptionPane.showMessageDialog(Adddata_usage.this,"Department with Same Department ID is present already\nInsertion Failed !!!");
			}
			else {
			*/{int i=Data_usagedetails.insertData_usage(did,day,devices_connected,data_bandwidth_GB,date);
			if(i>0){
				JOptionPane.showMessageDialog(Adddata_usage.this,"Department added successfully!");
			}else{
				JOptionPane.showMessageDialog(Adddata_usage.this,"Unknown Error !!!\nInsertion not completed");
			}
			}
			}}
		});
		
		/*JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e1) {
				Department.main(new String[]{});
				frame.dispose();
			}
			});*/
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(150)
							.addComponent(lblAdddata_usage))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lbldid)
								.addComponent(lblday)
								.addComponent(lbldevices_connected)
								.addComponent(lbldata_bandwidth_GB)
								.addComponent(lbldate)
								
								
								)
							.addGap(47)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							
								.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(125, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(50)
					.addComponent(btnAdddata_usage)
					.addGap(30)
//					.addComponent(btnBack)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblAdddata_usage)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbldid)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblday)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbldevices_connected)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbldata_bandwidth_GB)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbldate)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					
					
					
					
					
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						)
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnAdddata_usage, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							
//							.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							)
					
	)	);
		contentPane.setLayout(gl_contentPane);
	}

}
