import javax.swing.JFrame;  
import javax.swing.SwingUtilities;  
  
import org.jfree.chart.ChartFactory;  
import org.jfree.chart.ChartPanel;  
import org.jfree.chart.JFreeChart;  
import org.jfree.chart.plot.PlotOrientation;  
import org.jfree.data.category.CategoryDataset;  
import org.jfree.data.category.DefaultCategoryDataset;  
  
public class Bargraph extends JFrame {  
  
  private static final long serialVersionUID = 1L;  
  
  public Bargraph(String appTitle) {  
    super(appTitle);  
  
    
    CategoryDataset dataset = createDataset();  
      
  
    JFreeChart chart=ChartFactory.createBarChart(  
        "Bar Chart College Network", //Chart Title  
        "Day", // Category axis  
        "Frequency", // Value axis  
        dataset,  
        PlotOrientation.VERTICAL,  
        true,true,false  
       );  
  
    ChartPanel panel=new ChartPanel(chart);  
    setContentPane(panel);  
  }  
  
  private CategoryDataset createDataset() {  
    DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
  
    
    dataset.addValue(423, "Devices connected", "1");  
    dataset.addValue(482.81, "Data Bandwidth(GB)", "1");  

  
    dataset.addValue(235, "Devices connected", "2");  
    dataset.addValue(232.09, "Data Bandwidth(GB)", "2");   
  
    dataset.addValue(332, "Devices connected", "3");  
    dataset.addValue(414.22, "Data Bandwidth(GB)", "3");   
  
    dataset.addValue(278, "Devices connected", "4");  
    dataset.addValue(313.63, "Data Bandwidth(GB)", "4");   
  
    dataset.addValue(662, "Devices connected", "5");  
    dataset.addValue(1010.61, "Data Bandwidth(GB)", "5");   
  
  
    return dataset;  
  }  
  
  public static void main(String[] args) throws Exception {  
    SwingUtilities.invokeAndWait(()->{  
      Bargraph example=new Bargraph("Bar Chart Window");  
      example.setSize(800, 400);  
      example.setLocationRelativeTo(null);  

//      example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
      example.setVisible(true);  
    });  
  }  
}