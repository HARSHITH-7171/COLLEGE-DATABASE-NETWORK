
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Data_usagedetails{
 
	public static boolean checkdid(int did){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from data_usage where did=?");
			ps.setInt(1,did);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertData_usage(int did,int day,int devices_connected,float data_bandwidth_GB,String date){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into data_usage(did,day,devices_connected,data_bandwidth_GB,date) values(?,?,?,?,?)");
			ps.setInt(1,did);
			ps.setInt(2,day);
			ps.setInt(3,devices_connected);
			ps.setFloat(4,data_bandwidth_GB);
			ps.setString(5,date);
			
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deleteData_usage(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from data_usage where day=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
