

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableColumnModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.awt.event.ActionEvent;

public class Department extends JFrame {
	static Department frame;
	private JPanel contentPane;
	private JTable table;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Department();
					frame.setTitle("Data Usage Info");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Department() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(15, 30, 980, 650);
		
		contentPane = new JPanel();
		contentPane.setForeground(Color.MAGENTA);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblDepartmentinfo = new JLabel("Department Information");
		lblDepartmentinfo.setForeground(Color.RED);
		lblDepartmentinfo.setFont(new Font("Tahoma", Font.PLAIN, 22));
		
		JButton btnNewButton = new JButton("Add Department");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Adddepartment.main(new String[]{});
//			frame.dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
	/*	JButton btnUpdateDepartment = new JButton("Modify Data Usage Details");
		btnUpdateDepartment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			ModifyDepartment.main(new String[]{});
				frame.dispose();
			}
		});
		btnUpdateDepartment.setFont(new Font("Tahoma", Font.PLAIN, 13));*/
		
		JButton btnDeleteDepartment = new JButton("Delete Data Usage details");
		btnDeleteDepartment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			
			Deletedepartment.main(new String[]{});
//				frame.dispose();
			}
		});
		btnDeleteDepartment.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnViewDepartment = new JButton("View All Data usage");
		btnViewDepartment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data[][]=null;
				String column[]=null;
				try{
					Connection con=DB.getConnection();
					PreparedStatement ps=con.prepareStatement("select * from departments",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					ResultSet rs=ps.executeQuery();
					
					ResultSetMetaData rsmd=rs.getMetaData();
					int cols=rsmd.getColumnCount();
					column=new String[cols];
					for(int i=1;i<=cols;i++){
						column[i-1]=rsmd.getColumnName(i);
					}
					
					rs.last();
					int rows=rs.getRow();
					rs.beforeFirst();

					data=new String[rows][cols];
					int count=0;
					while(rs.next()){
						for(int i=1;i<=cols;i++){
							data[count][i-1]=rs.getString(i);
						}
						count++;
					}
					con.close();
				}catch(Exception e1){System.out.println(e1);}
				
				
				
				
				table = new JTable(data,column);
				table.setDefaultEditor(Object.class, null);
				
				
				TableColumnModel columnModel = table.getColumnModel();

				columnModel.getColumn(0).setPreferredWidth(20);
				columnModel.getColumn(1).setPreferredWidth(20);
				
				
				
				JScrollPane sp=new JScrollPane(table);
				add(sp);
				sp.setBounds(400,100,500,350);
				
//				setBounds(70, 30, 1200, 650);
				
			
				
				
				ListSelectionModel model = table.getSelectionModel();
				model.addListSelectionListener((ListSelectionListener) new ListSelectionListener() {

					public void valueChanged(ListSelectionEvent e) {
						int sel = model.getMinSelectionIndex();
//							tfid3.setText(""+(sel+1));
						System.out.println(table.getValueAt(sel, 0));

						Deletedepartment.gettf().setText(""+table.getValueAt(sel, 0));
					}

				});
				
				
				

				
				
//				ViewDepartment.main(new String[]{});
			}
		});
		btnViewDepartment.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Menu.main(new String[]{});
			frame.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.CENTER, gl_contentPane.createSequentialGroup()
					.addComponent(lblDepartmentinfo)
					.addGap(100))
				.addGroup(Alignment.CENTER ,gl_contentPane.createSequentialGroup()
					.addGap(132)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnViewDepartment, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnDeleteDepartment, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						//.addComponent(btnUpdateDepartment, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(101, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblDepartmentinfo)
					.addGap(38)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					//.addComponent(btnUpdateDepartment, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					//.addGap(18)
					.addComponent(btnDeleteDepartment, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnViewDepartment, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
				    .addContainerGap(16, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
