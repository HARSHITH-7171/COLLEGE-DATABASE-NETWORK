
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Departmentdetails{
 
	public static boolean checkdid(int did){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from departments where did=?");
			ps.setInt(1,did);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertDepartment(int did,String dname,String ip_address){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into departments(did,dname,ip_address) values(?,?,?)");
			ps.setInt(1,did);
			ps.setString(2,dname);
			ps.setString(3,ip_address);
			
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deleteDepartment(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from departments where did=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
