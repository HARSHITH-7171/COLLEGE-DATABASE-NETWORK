
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableColumnModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.awt.event.ActionEvent;

public class Graph extends JFrame {
	static Graph frame;
	private JPanel contentPane;
	private JTable table;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Graph();
					frame.setTitle("Data Usage Info");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Graph() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(15, 30, 980, 650);
		
		contentPane = new JPanel();
		contentPane.setForeground(Color.MAGENTA);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblGraphinfo = new JLabel("Graph Information");
		lblGraphinfo.setForeground(Color.RED);
		lblGraphinfo.setFont(new Font("Tahoma", Font.PLAIN, 22));
		
		JButton btnNewButton = new JButton("View Bar Graph");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Bargraph.main(new String[]{});
			frame.dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
	/*	JButton btnUpdateGraph = new JButton("Modify Data Usage Details");
		btnUpdateGraph.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			ModifyGraph.main(new String[]{});
				frame.dispose();
			}
		});
		btnUpdateGraph.setFont(new Font("Tahoma", Font.PLAIN, 13));*/
		
//		JButton btnDeleteGraph = new JButton("Delete Data Usage details");
//		btnDeleteGraph.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
				
				
			
//			DeleteGraph.main(new String[]{});
//				frame.dispose();
//			}
//		});
//		btnDeleteGraph.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnViewGraph = new JButton("View Graph Details");
		btnViewGraph.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data[][]=null;
				String column[]=null;
				try{
					Connection con=DB.getConnection();
					PreparedStatement ps=con.prepareStatement("select * from graph",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					ResultSet rs=ps.executeQuery();
					
					ResultSetMetaData rsmd=rs.getMetaData();
					int cols=rsmd.getColumnCount();
					column=new String[cols];
					for(int i=1;i<=cols;i++){
						column[i-1]=rsmd.getColumnName(i);
					}
					
					rs.last();
					int rows=rs.getRow();
					rs.beforeFirst();

					data=new String[rows][cols];
					int count=0;
					while(rs.next()){
						for(int i=1;i<=cols;i++){
							data[count][i-1]=rs.getString(i);
						}
						count++;
					}
					con.close();
				}catch(Exception e1){System.out.println(e1);}
				
				
				
				
				table = new JTable(data,column);
				table.setDefaultEditor(Object.class, null);
				
				
				TableColumnModel columnModel = table.getColumnModel();

				columnModel.getColumn(0).setPreferredWidth(20);
				columnModel.getColumn(1).setPreferredWidth(20);
				
				
				
				JScrollPane sp=new JScrollPane(table);
				add(sp);
				sp.setBounds(400,100,500,350);
				
//				setBounds(70, 30, 1200, 650);
				
			
				
				
				ListSelectionModel model = table.getSelectionModel();
				model.addListSelectionListener((ListSelectionListener) new ListSelectionListener() {

					public void valueChanged(ListSelectionEvent e) {
						int sel = model.getMinSelectionIndex();
//							tfid3.setText(""+(sel+1));
//						System.out.println(table.getValueAt(sel, 0));

//						DeleteGraph.gettf().setText(""+table.getValueAt(sel, 0));
					}

				});
				
				
				

				
				
//				ViewGraph.main(new String[]{});
			}
		});
		btnViewGraph.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Menu.main(new String[]{});
				frame.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.CENTER, gl_contentPane.createSequentialGroup()
					.addComponent(lblGraphinfo)
					.addGap(100))
				.addGroup(Alignment.CENTER ,gl_contentPane.createSequentialGroup()
					.addGap(132)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnViewGraph, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
//						.addComponent(btnDeleteGraph, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						//.addComponent(btnUpdateGraph, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(101, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblGraphinfo)
					.addGap(38)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					//.addComponent(btnUpdateGraph, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					//.addGap(18)
//					.addComponent(btnDeleteGraph, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
//					.addGap(18)
					.addComponent(btnViewGraph, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
				    .addContainerGap(16, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
